UNCOMMON 27 - smart-processor (Razorpay starter)

CONTENTS
- index.ts: Supabase Edge Function for Razorpay order creation and payment-signature verification.

IMPORTANT LIMITATION
This package does NOT yet create/update rows in your Supabase orders or order_items tables.
Your known orders table columns were available in the earlier setup, but the exact order_items columns and trusted product/variant price columns are not confirmed here. Those are required to safely create orders and calculate totals on the server. Do not enable live checkout using browser-supplied amounts.

SUPABASE SECRETS
In Supabase Dashboard -> Edge Functions -> Secrets, add:
RAZORPAY_KEY_ID = your Razorpay key ID (test key while testing)
RAZORPAY_KEY_SECRET = your Razorpay key secret
Do not put the secret in website/frontend code or in this ZIP.

DEPLOY
1. Extract this ZIP.
2. In your Supabase project, open Edge Functions and create/open the function named smart-processor.
3. Replace its index.ts with the index.ts from this package (or deploy using the Supabase CLI if you use it).
4. Deploy the function.
5. Keep Razorpay in Test Mode until end-to-end testing is complete.

REQUEST: CREATE RAZORPAY ORDER
POST JSON:
{
  "action": "create_payment_order",
  "amount": 49900,
  "currency": "INR",
  "receipt": "u27_test_001"
}
Amount is paise (49900 = Rs 499). The amount must be validated/recalculated by trusted server-side cart logic before production use.

REQUEST: VERIFY PAYMENT
POST JSON:
{
  "action": "verify_payment",
  "razorpay_order_id": "order_...",
  "razorpay_payment_id": "pay_...",
  "razorpay_signature": "..."
}

NEXT REQUIRED STEP
Before enabling automatic order placement, confirm the exact columns in public.order_items and public.products / public.product_variants (especially product ID, variant ID, quantity, unit price and line total). Then the function can be completed to calculate totals from database prices and write verified orders safely.
