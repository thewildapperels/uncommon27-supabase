// UNCOMMON 27 - Supabase Edge Function: smart-processor
// Handles Razorpay order creation and payment-signature verification.
// IMPORTANT: Before going live, calculate the cart amount on the server from
// trusted product/variant prices in your database. Never trust a browser amount.

import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const RAZORPAY_KEY_ID = Deno.env.get("RAZORPAY_KEY_ID") ?? "";
const RAZORPAY_KEY_SECRET = Deno.env.get("RAZORPAY_KEY_SECRET") ?? "";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function hmacSha256Hex(secret: string, message: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(message));
  return [...new Uint8Array(signature)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  if (!RAZORPAY_KEY_ID || !RAZORPAY_KEY_SECRET) {
    return json({ error: "Razorpay secrets are not configured in Supabase." }, 500);
  }

  try {
    const body = await req.json();
    const action = body?.action;

    if (action === "create_payment_order") {
      const amount = Number(body?.amount);
      const currency = String(body?.currency ?? "INR").toUpperCase();
      const receipt = String(body?.receipt ?? `u27_${crypto.randomUUID().replaceAll("-", "").slice(0, 20)}`);

      // Amount is in paise. This is only safe after the server validates it
      // against trusted database prices; do not pass an unchecked cart total.
      if (!Number.isSafeInteger(amount) || amount < 100 || amount > 50000000) {
        return json({ error: "Invalid amount. Provide paise as a whole number." }, 400);
      }
      if (currency !== "INR") return json({ error: "Only INR is enabled." }, 400);

      const auth = btoa(`${RAZORPAY_KEY_ID}:${RAZORPAY_KEY_SECRET}`);
      const response = await fetch("https://api.razorpay.com/v1/orders", {
        method: "POST",
        headers: {
          "Authorization": `Basic ${auth}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ amount, currency, receipt }),
      });
      const result = await response.json();
      if (!response.ok) {
        console.error("Razorpay order creation failed", result);
        return json({ error: "Razorpay could not create the payment order." }, 502);
      }

      return json({
        success: true,
        key_id: RAZORPAY_KEY_ID,
        razorpay_order_id: result.id,
        amount: result.amount,
        currency: result.currency,
        receipt: result.receipt,
      });
    }

    if (action === "verify_payment") {
      const razorpay_order_id = String(body?.razorpay_order_id ?? "");
      const razorpay_payment_id = String(body?.razorpay_payment_id ?? "");
      const razorpay_signature = String(body?.razorpay_signature ?? "");
      if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
        return json({ error: "Missing Razorpay payment verification fields." }, 400);
      }

      const expected = await hmacSha256Hex(
        RAZORPAY_KEY_SECRET,
        `${razorpay_order_id}|${razorpay_payment_id}`,
      );
      const verified = safeEqual(expected, razorpay_signature.toLowerCase());
      if (!verified) return json({ success: false, verified: false, error: "Payment signature is invalid." }, 400);

      return json({
        success: true,
        verified: true,
        razorpay_order_id,
        razorpay_payment_id,
        message: "Payment signature verified. Order database update is not enabled in this starter package.",
      });
    }

    return json({ error: "Unknown action. Use create_payment_order or verify_payment." }, 400);
  } catch (error) {
    console.error("smart-processor error", error);
    return json({ error: "Invalid request or unexpected server error." }, 500);
  }
});
